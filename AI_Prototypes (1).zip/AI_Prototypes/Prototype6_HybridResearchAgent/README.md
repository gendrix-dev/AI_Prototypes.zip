# Prototype 6 — Hybrid Research Agent
**Aligned to:** Ivanova et al. (2025) | **Class:** A (Solution prototype)

This is the paper's recommended solution implemented as working software: Query decomposition + RAG retrieval + step-by-step reasoning chain. The most complete mitigation architecture in the repo.

## Setup
Add research PDFs to `knowledge_base/` folder before running.

## Test Queries
- "What are the main differences between RAG and fine-tuning for reducing hallucinations?"
- "Summarize the key findings on multi-agent fact checking from recent literature"
