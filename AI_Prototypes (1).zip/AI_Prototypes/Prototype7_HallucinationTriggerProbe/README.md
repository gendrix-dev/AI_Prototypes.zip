# Prototype 7 — Hallucination Trigger Probe
**Aligned to:** Bouchard et al. (2025) Library Hallucinations | **Class:** B

Tests two specific hallucination triggers from P7: time/date signals and query typos. Date-injected queries reliably cause Gemini to fabricate version numbers and release dates.

## Test Queries
- Base: "What version of Python should I use for ML?"
- (Workflow auto-injects date signals and typos to the same query)

## What to Observe
Date-injected version produces fabricated "2026 release" or version numbers — directly confirming P7's time-signal finding.
