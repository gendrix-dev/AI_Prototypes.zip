# Prototype 5 — Root Cause Classifier
**Aligned to:** Al-Rashid et al. (2026) | **Class:** B

Classifies each hallucination into P5's three root cause domains: Architecture / Training Data / Context. Produces a percentage distribution showing which failure type dominates.

## Test Queries
- "What is catastrophic forgetting?" (tests architecture understanding)
- "What papers were published about RAG in 2025?" (tests training data limits)
