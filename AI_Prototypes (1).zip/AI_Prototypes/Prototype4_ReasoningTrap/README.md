# Prototype 4 — Reasoning Trap Demonstrator
**Aligned to:** Kim et al. (2025) ICLR 2026 Submission | **Class:** B (Paradox demonstration)

Demonstrates the Reasoning Trap: 5-step CoT produces MORE tool/API hallucinations than 1-step direct answers. The most counterintuitive finding in the corpus.

## Test Queries (use technical questions about libraries/APIs)
- "How do I use the OpenAI Assistants API to create a thread?"
- "What Flowise nodes are available for memory management?"
