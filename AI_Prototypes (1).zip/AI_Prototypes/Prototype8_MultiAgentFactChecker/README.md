# Prototype 8 — Multi-Agent Fact Checker ⭐

**Aligned to:** Nwosu et al. (2025) *Hallucination to Truth: Fact-Checking Review*  
**Research Class:** A (Prompt-Reducible via Architecture)  
**Thesis:** Three-agent pipeline (Answer → Verify → Judge) catches hallucinations single agents miss

---

## What This Proves
P8 found that multi-agent architecture with step-by-step reasoning is the strongest factuality strategy. This prototype implements exactly that: Agent 1 answers freely, Agent 2 forensically verifies every claim, Agent 3 delivers a final reliability verdict.

## How to Run
1. Import `flowise_workflow.json` into Flowise
2. Add your Gemini API key to all three agent nodes
3. Send any factual claim or question as input

## Test Queries (Feed these to expose hallucinations)
- "When was GPT-4 released and what was its benchmark score on MMLU?"
- "Who invented the transformer architecture and at which company?"
- "What is the context window size of Claude 3 Opus?"

## What to Observe
- Agent 1 answers with confidence — may contain fabrications
- Agent 2 flags specific claims as VERIFIED / UNCERTAIN / HALLUCINATED
- Agent 3 issues ACCEPT / REVISE / REJECT with a reliability score
- Watch for cases where Agent 3 REVISES or REJECTS Agent 1's answer

## Sample Output
```
[AGENT 1 - ANSWER]
GPT-4 was released in March 2023 with an MMLU score of 86.4%...

[AGENT 2 - VERIFICATION]
Claim 1: "Released March 2023" → VERIFIED
Claim 2: "MMLU score 86.4%" → UNCERTAIN (exact figure not verifiable)
Confidence Score: 65/100

[AGENT 3 - FINAL VERDICT]
REVISE — The release date is correct but the MMLU score requires verification.
Corrected answer: GPT-4 scored approximately 86% on MMLU (exact figure varies by source).
RELIABILITY SCORE: 7/10
```

## Node Flow
```
User Query → Agent 1 (Answerer, temp=0.7)
                  ↓
             Agent 2 (Verifier, temp=0.2) ← Original Query
                  ↓
             Agent 3 (Judge, temp=0.1) ← Agent 1 Answer
                  ↓
             Final Verified Output
```
