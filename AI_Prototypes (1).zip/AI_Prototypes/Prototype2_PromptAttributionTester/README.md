# Prototype 2 — Prompt Attribution Tester
**Aligned to:** Okonkwo et al. (2025) Frontiers in AI | **Class:** A/B

Tests 3 prompt styles (Vague / Chain-of-Thought / Constrained) on the same model to isolate whether failure comes from the prompt or the model architecture itself.

## Test Queries
- "Tell me about the latest AI models" (vague enough to trigger fabrication)
- "What libraries does LangChain use?"
