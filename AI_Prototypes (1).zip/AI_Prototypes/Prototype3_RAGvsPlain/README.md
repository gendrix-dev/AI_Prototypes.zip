# Prototype 3 — RAG vs Plain Gemini Comparator ⭐

**Aligned to:** Zhang et al. (2025) *Large Language Models Hallucination: A Comprehensive Survey*  
**Research Class:** A (Prompt-Reducible)  
**Thesis:** RAG-grounded Gemini produces 20–40% fewer hallucinations than plain Gemini

---

## What This Proves
P3 found that no single technique eliminates hallucination but RAG + prompting together is the strongest combination. This prototype puts that claim to a live test by running the same query through two parallel pipelines and comparing results side by side.

## How to Run
1. Import `flowise_workflow.json` into Flowise
2. Add your Gemini API key to both Gemini nodes
3. Add PDF documents to `knowledge_base/` folder
4. Load the workflow and send a factual research question

## Test Queries
- "What is the hallucination rate of GPT-4 on TruthfulQA?"
- "Who authored the Attention is All You Need paper and when?"
- "What is the difference between RAG and fine-tuning?"

## What to Observe
- Plain Gemini may give confident but unverifiable answers
- RAG Gemini should cite context or say "I don't have enough information"
- Compare specificity, accuracy, and source citation between both

## Sample Output
```
PLAIN GEMINI:
"GPT-4 achieves approximately 85% accuracy on TruthfulQA..."
(Note: fabricated specific percentage with no source)

RAG GEMINI:
"Based on the retrieved context, P3 reports hallucination reduction
of 20-40% using hybrid techniques. Source: Zhang et al. 2025, chunk 3"
```

## Node Flow
```
User Query → [Plain Gemini] ──────────────────────────────→ Side-by-Side Output
           → [Knowledge Base] → [Embeddings] → [Vector Store]
                                                    → [Retriever] → [RAG Gemini] ↗
```
