# 🧠 AI_Prototypes — LLM Hallucination Research Project

> **"Prompt Engineering as Harm Reduction: What Prompting Achieves vs. What It Provably Cannot"**
> 
> This repository contains 8 working Flowise prototypes, each directly aligned to one of 8 peer-reviewed research papers on LLM hallucination and prompt engineering limitations.

---

## 📋 Project Overview

This project is the **practical implementation** of a systematic literature review examining whether prompt engineering can fix LLM failures. Each prototype either:
- **Demonstrates a failure** (proving a paper's thesis live), or
- **Tests a mitigation** (implementing a paper's recommended solution)

**Tech Stack:** Flowise + Google Gemini API

---

## 🗂️ Repository Structure

```
AI_Prototypes/
├── Prototype1_HallucinationStressTester/     → P1: Fundamental Limits (2026)
├── Prototype2_PromptAttributionTester/       → P2: Hallucination Attribution (2025)
├── Prototype3_RAGvsPlain/                    → P3: Comprehensive Survey (2025) ⭐ START HERE
├── Prototype4_ReasoningTrap/                 → P4: Reasoning Trap (2025)
├── Prototype5_RootCauseClassifier/           → P5: Detection & Mitigation (2026)
├── Prototype6_HybridResearchAgent/           → P6: RAG + Reasoning (2025)
├── Prototype7_HallucinationTriggerProbe/     → P7: Library Hallucinations (2025)
├── Prototype8_MultiAgentFactChecker/         → P8: Fact-Checking Review (2025) ⭐ MOST IMPRESSIVE
└── ResearchPaper.pdf                         → Full literature review
```

---

## ⚡ Quick Start

### Prerequisites
- [Flowise](https://flowiseai.com/) running locally (`npx flowise start`)
- Google Gemini API key from [Google AI Studio](https://aistudio.google.com/)

### Setup Steps
1. Clone this repository
2. Open Flowise at `http://localhost:3000`
3. Go to **Chatflows → Import**
4. Select any `flowise_workflow.json` file
5. Replace `YOUR_GEMINI_API_KEY` with your actual key in each node
6. Click **Save** and **Test**

---

## 📊 Prototype Summary Table

| # | Prototype | Paper | Class | What It Shows |
|---|-----------|-------|-------|---------------|
| 1 | Hallucination Stress Tester | P1 — Sharma et al. 2026 | B | Same query 6 ways → contradictions prove hallucination is inevitable |
| 2 | Prompt Attribution Tester | P2 — Okonkwo et al. 2025 | A/B | 3 prompt styles → isolates whether failure is prompt or model |
| 3 | RAG vs Plain Comparator | P3 — Zhang et al. 2025 | A | Side-by-side: grounded vs ungrounded responses |
| 4 | Reasoning Trap Demonstrator | P4 — Kim et al. 2025 | B | 1-step vs 5-step CoT → complex reasoning increases tool errors |
| 5 | Root Cause Classifier | P5 — Al-Rashid et al. 2026 | B | Classifies failures as architecture/data/context |
| 6 | Hybrid Research Agent | P6 — Ivanova et al. 2025 | A | RAG + reasoning chain — the paper's recommended solution |
| 7 | Hallucination Trigger Probe | P7 — Bouchard et al. 2025 | B | Date signals & typos spike fabrication rates |
| 8 | Multi-Agent Fact Checker | P8 — Nwosu et al. 2025 | A | 3 agents: Answer → Verify → Judge |

**Class A** = Prompt-reducible failure | **Class B** = Prompt-invariant failure

---

## 🔗 Connection to Research Paper

The research paper (included as `ResearchPaper.pdf`) establishes a **two-class taxonomy**:
- **Class A failures** can be reduced by better prompting
- **Class B failures** are mathematically invariant to any prompting intervention

These prototypes are live experiments that test both classes. Prototype 3, 6, and 8 demonstrate Class A mitigations. Prototypes 1, 4, 5, and 7 demonstrate Class B failures that persist despite prompting.

---

## 📬 Contact

Submitted: March 2026 | Research Methods in AI Systems
