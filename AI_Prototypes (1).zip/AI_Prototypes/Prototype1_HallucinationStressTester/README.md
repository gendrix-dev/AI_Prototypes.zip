# Prototype 1 — Hallucination Stress Tester

**Aligned to:** Sharma et al. (2026) *On the Fundamental Limits of LLMs at Scale*  
**Research Class:** B (Prompt-Invariant — proves the ceiling)  
**Thesis:** Hallucination is mathematically inevitable — same query rephrased 6 ways produces contradictions

## How to Run
1. Import `flowise_workflow.json` → add Gemini API key
2. Enter a factual question about AI research
3. The workflow auto-generates 5 rephrased versions + answers all 6
4. Consistency Analyzer reports hallucination rate

## Best Test Queries
- "What year was the BERT model published?"
- "How many parameters does LLaMA 2 have?"
- "What benchmark did GPT-4 achieve on HumanEval?"

## What to Observe
Contradictions between the 6 answers. The Consistency Analyzer will output a HALLUCINATION RATE showing what % of answers contained inconsistent or fabricated claims — confirming P1's mathematical inevitability theorem.
